#ifdef PYTHIA8_COMPLETE_ROOT_DICTIONARY
#include "Pythia8/Pythia.h"
#else
#include "Pythia8/Event.h"
#endif

using namespace Pythia8;
