#!/bin/sh
if [ ! $?DYLD_LIBRARY_PATH ]; then
  export DYLD_LIBRARY_PATH=/usr/local/bin/x86_64-mac106-gcc42-opt//lib
fi
if [ $?DYLD_LIBRARY_PATH ]; then
  export DYLD_LIBRARY_PATH=${DYLD_LIBRARY_PATH}:/usr/local/bin/x86_64-mac106-gcc42-opt//lib
fi
